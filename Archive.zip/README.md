# Cross browser add-on URL Encoder Decoder
A cross browser add-on to encode/decode urls quickly in browser popul. Works well with Firefox & Chrome.

# Firefox listing link
https://addons.mozilla.org/en-US/firefox/user/ram_vaishnav/

# Description
* Enjoy seamless experience from this very light weight add-on.
* This addon is completely safe to use, no data is sent to server.
* This is an open source project, find the code on https://github.com/gurumukhi/.

Support:
* Kindly feel free to open an issue on addon repo at https://github.com/gurumukhi/ for any support.